﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public interface IIdentifible
    {
        public string Id { get; }
    }
}
